# import packages
import sys

sys.path.append('/data4/dm_share')
from tools.HiveLib import HiveLib
import pandas as pd
import numpy as np
import xlwt
import sys

sys.path.append('/data4/dm_share')
from utils.import_utils import *
import matplotlib.pyplot as plt
import matplotlib as mpl
import copy

mpl.style.use('ggplot')
import prestodb
import os
import json

def execute(sql):
    # 获取presto的连接
    conn = prestodb.dbapi.connect(
        host='10.105.110.176',
        port=8080,
        user='mapeng',
        catalog='hive',
        schema='dwb',
    )
    cur = conn.cursor()
    cur.execute(sql)
    # 返回执行结果
    rows = cur.fetchall()
    conn.commit()
    # 关闭连接
    conn.close()
    # 返回结果
    return rows


def extract_nested_json(x):
    """
    args:
        x: json-formated data
    return:
        anti-nested formated data 将多层嵌套的json提取出只有一层的json，返回数据也是json类型
    example:
        df.data.map(extract_nested_json).apply(lambda s:pd.Series(json.loads(s)))
    """
    global_dic = {}
    x = x.replace('\\\\', '\\')

    def json_to_dict(key, value, prefix=''):
        if isinstance(value, dict):
            for k, v in value.items():
                if key and prefix:
                    json_to_dict(k, v, prefix + '_' + key)
                elif key and not prefix:
                    json_to_dict(k, v, key)
                elif not key and prefix:
                    json_to_dict(k, v, prefix)
                else:
                    json_to_dict(k, v, '')
        else:
            if prefix:
                key = prefix + '_' + key
            global_dic[key] = value

    try:
        tmp = json.loads(x)
        json_to_dict('', tmp)
    except:
        global_dic['_ERROR_'] = 1
    return json.dumps(global_dic)


def get_round(s, num=3):
    if s is np.nan:
        return s
    elif type(s) == str:
        return s
    return round(s, num)


def prob_to_score(p, A=473.48, B=72.14):
    """
    args:
        p: 模型输出的概率，对1的概率
        A: 基础分补偿，不用修改
        B: 刻度，不用修改
    return:
        score: 分数，头尾掐掉
    """
    odds = p / (1 - p)
    score = A - B * np.log(odds)
    score = max(350, score)
    score = min(950, score)
    return round(float(score), 4)


def get_data(user, data_table, out_dir, is_None=True):
    """
    real_data：与沙盒模拟数据时间段一致，从线下宽表中取出的数据，必须包含apply_risk_id
    example:
    online_data_table: pingtai_lk_1108_1110
    oot_data_table: pingtai_lk_oot
    注释：所有表存在dm_temp
    """
    # 真实数据
    hive_lib = HiveLib(user=user)
    df = hive_lib.saveTableToLocal('dm_temp', data_table, out_dir=out_dir, out_type='pkl', overwrite_file=True,
                                   delimiter='\x01')
    df = df.set_index('apply_risk_id')
    if is_None:
        for i in df.columns:
            if None in df[i]:
                print('real data %s columns have None' % i)
            df[i] = df[i].replace('null', None)
        df = df.apply(pd.to_numeric, errors='ignore')
    else:
        print('real data %s columns have None' % i)
        raise Exception("data have None")
    return df


def get_sandbox_data(model_id, task_id=None, is_None=True):
    if task_id == None:
        sql = 'select apply_risk_id,request,score from sandbox.sandbox.offline_model_record where offline_model_record.model_id = ' + str(
            model_id)
    else:
        sql = 'select apply_risk_id,request,score from sandbox.sandbox.offline_model_record where offline_model_record.model_id = ' + str(
            model_id) + ' and offline_model_record.task_id = ' + str(task_id)
    df_sandbox = pd.DataFrame(execute(sql), columns=['apply_risk_id', 'request', 'score'])
    sandbox = df_sandbox.request.map(extract_nested_json).apply(lambda s: pd.Series(json.loads(s)))
    sandbox['score'] = df_sandbox.score
    sandbox['apply_risk_id'] = df_sandbox.apply_risk_id
    sandbox = sandbox.set_index('apply_risk_id')

    if is_None:
        for i in sandbox.columns:
            if None in sandbox[i]:
                print('sandbox data %s columns have None' % i)
            sandbox[i] = sandbox[i].replace('null', None)
        sandbox = sandbox.apply(pd.to_numeric, errors='ignore')
    else:
        print('real data %s columns have None' % i)
        raise Exception("data have None")

    return sandbox


def plot_normal_curve(simu_score, oot_score):
    import math
    u1 = np.mean(simu_score)
    u2 = np.mean(oot_score)
    sig1 = np.std(simu_score)
    sig2 = np.std(oot_score)

    x_1 = np.linspace(u1 - 6 * sig1, u1 + 6 * sig1, 10000)
    x_2 = np.linspace(u2 - 10 * sig2, u2 + 10 * sig2, 10000)

    f, ax = plt.subplots(dpi=200, nrows=1, ncols=1, sharex=True, sharey=True)
    y_sig1 = np.exp(-(x_1 - u1) ** 2 / (2 * sig1 ** 2)) / (math.sqrt(2 * math.pi) * sig1)
    y_sig2 = np.exp(-(x_2 - u2) ** 2 / (2 * sig2 ** 2)) / (math.sqrt(2 * math.pi) * sig2)

    ax.plot(x_1, y_sig1, label='score distribution: sandbox data')
    ax.plot(x_2, y_sig2, label='score distribution: oot data')
    ax.set_xlabel('Score')
    ax.set_ylabel('Probability')
    ax.legend(loc='upper right')
    plt.savefig('数据score分布图' + '.png')
    plt.show()


def get_Bscore(model_id, strat_time, end_time):
    sql = sql = "select ar1.apply_risk_individual_id riskdata_individual_id,ar1.apply_risk_id source_19_apply_risk_id,ar1.apply_risk_type,ar1.apply_risk_created_at,ar1.apply_risk_score,ar1.apply_risk_result ,offline_model_record.score from dwb.dwb_r_apply_risk ar1 left join sandbox.sandbox.offline_model_record on offline_model_record.apply_risk_id=ar1.apply_risk_id and offline_model_record.model_id= " + str(
        model_id) + " where ar1.apply_risk_source=19 and ar1.apply_risk_created_at between '" + str(
        strat_time) + "' and '" + str(
        end_time) + "' and ar1.apply_risk_type=2 and ar1.apply_risk_score>\'0\' order by offline_model_record.score desc"
    Bscore = pd.DataFrame(execute(sql),
                          columns=['risk_data_individual_id', 'source_19_apply_risk_id', 'apply_risk_type',
                                   'apply_risk_created_at', 'apply_risk_score', 'apply_risk_result', 'score'])
    return Bscore


def get_diff(df, sandbox, model_id, equipment_app_names_value):
    common_col = sandbox.columns & df.columns
    common_ix = sandbox.index & df.index
    df1 = pd.DataFrame(df.ix[common_ix][common_col]).drop([equipment_app_names_value], axis=1).applymap(get_round)
    sandbox1 = pd.DataFrame(sandbox.ix[common_ix][common_col]).drop([equipment_app_names_value], axis=1).applymap(
        get_round)
    diff = pd.DataFrame(sandbox1 == df1)
    diff_dict = {}
    for i in common_col:
        if i != equipment_app_names_value:
            diff_dict[i] = diff[diff[i] == False].index.tolist()

    path_diff = str(model_id) + '_sandbox_real_diff.xlsx'
    writer_diff = pd.ExcelWriter(path_diff, engine='openpyxl')

    for key, values in diff_dict.items():
        if key != equipment_app_names_value:
            diff_df = pd.DataFrame()
            diff_df['apply_risk_id'] = values
            diff_df['real_data'] = df[key].loc[values].tolist()
            diff_df['sandbox_data'] = sandbox[key].loc[values].tolist()
            diff_df.to_excel(writer_diff, sheet_name=key, index=True, encoding='gbk')

    writer_diff.save()
    writer_diff.close()


def get_result(user, real_data_table, oot_data_table, y_pro_oot, out_dir, model_id, strat_time, end_time, rename_col, A,
               equipment_app_names_value, task_id=None, is_None=True):
    # user : 用户名
    # real_data_table ：数据库数据表明或者DataFrame的数据
    # oot_data_table ： oot数据库数据表明或者DataFrame的数据
    # y_pro_oot ：oot数据库概率的字段名称
    # out_dir ：保存文件路径
    # model_id ：沙盒环境模型id
    # task_id ： 沙盒环境任务id
    # strat_time end_time ：Bscore的开始时间和结束时间
    # equipment_app_names_value : app名称
    # is_None：数据集含有None是否打断


    """
    example: key为沙盒数据特征名，value为模型用特征名
    rename_col = {
        'Equipment_app_names_v2'                                  : 'equipment_app_names_v2',
        'EquipmentOs'                                             : 'mbs_equipment_os',
        'ApplyCommitAt'                                           : 'apply_crisk_created_at',
        'Individual_Identity'                                     : 'individual_identity',
        'Jxl_Contact_morning_Avg'                                 : 'jxl_avg_morning',
        'Baidu_Panshi_Duotou_Identity_Score'                      : 'baidu_panshi_duotou_identity_score',
        'Baidu_Panshi_Prea_Score'                                 : 'baidu_panshi_prea_score',
        'Jxl_Contact_C1m_Then_0_Ratio'                            : 'jxl_c1m_gre_0_ratio',
    }
    """
    rename_n = pd.DataFrame([rename_col]).T
    rename_n = rename_n.reset_index()
    rename_last = rename_n.set_index(0)
    rename_last.columns = ['特征系统端特证名']

    rename_col['score'] = 'score'

    sandbox = get_sandbox_data(model_id, task_id)

    if type(real_data_table) == str:
        df = get_data(user, real_data_table, out_dir)
    else:
        df = real_data_table

    if type(oot_data_table) == str:
        oot = get_data(user, oot_data_table, out_dir)
    else:
        oot = oot_data_table
    # oot = get_data(user,real_data_table,out_dir)


    sandbox.columns = [c.lower() for c in sandbox.columns]
    rename_col = dict(zip([k.lower() for k in rename_col.keys()], rename_col.values()))
    sandbox.rename(columns=rename_col, inplace=True)

    # target_dir = 'reportsource'
    # if not os.path.exists(target_dir):
    #     os.mkdir(target_dir)

    path = str(model_id) + '_sandbox_data_check_report.xlsx'
    writer = pd.ExcelWriter(path, engine='openpyxl')

    # consistency comparison feature mean median std comparison between real data  and sandbox data
    common_col = sandbox.columns & df.columns
    common_ix = sandbox.index & df.index
    df1 = pd.DataFrame(df.ix[common_ix][common_col].drop([equipment_app_names_value], axis=1)).round().fillna(-999)
    sandbox1 = pd.DataFrame(sandbox.ix[common_ix][common_col].drop([equipment_app_names_value], axis=1)).applymap(
        get_round).fillna(-999)
    consistency_rate = (pd.DataFrame((sandbox1 == df1).apply(np.mean), columns=['consistency rate'])).T
    consistency_rate[equipment_app_names_value] = pd.Series((str(df.ix[k].equipment_app_names_v2).split().sort() == str(
        sandbox.ix[k].equipment_app_names_v2).split().sort()) for k in common_ix).mean()
    result_con = consistency_rate.T
    result_con['差异数（True表示不同，False表示相同'] = (1 - result_con['consistency rate'].apply(pd.to_numeric)) * len(common_ix)
    result_con['差异率'] = 1 - result_con['consistency rate']

    sandbox_describe = sandbox.ix[common_ix][common_col].drop(equipment_app_names_value, axis=1).describe().T[
        ['mean', '50%', 'std']]
    df_describe = df.ix[common_ix][common_col].drop(equipment_app_names_value, axis=1).describe().T[
        ['mean', '50%', 'std']]

    df_oot_sandbox_mean = pd.concat([sandbox_describe, df_describe], axis=1)
    df_oot_sandbox_mean.columns = ['sandbox_data_mean', 'sandbox_data_median', 'sandbox_data_std', 'real_data_mean',
                                   'real_data_median', 'real_data_std']
    df_oot_sandbox_mean['sandbox_real_diff'] = np.abs(
        (df_oot_sandbox_mean['sandbox_data_mean'] / df_oot_sandbox_mean['real_data_mean']) - 1)
    df_oot_sandbox_mean = df_oot_sandbox_mean.merge(rename_last, left_index=True, right_index=True, how='inner')

    df_sandbox = df_oot_sandbox_mean.merge(result_con.drop('consistency rate', axis=1), left_index=True,
                                           right_index=True, how='inner')
    df_sandbox.to_excel(writer, sheet_name='对比结果总量', index=True, encoding='gbk')

    # different detail

    diff = pd.DataFrame(sandbox1 == df1)
    diff = pd.DataFrame(diff, dtype=str)
    diff_dict = {}
    for i in common_col:
        if i != equipment_app_names_value:
            diff_dict[i] = diff[diff[i] == 'False'].index.tolist()

    for key, values in diff_dict.items():
        if key != equipment_app_names_value:
            diff_df = pd.DataFrame()
            diff_df['apply_risk_id'] = values
            diff_df['real_data'] = df[key].loc[values].tolist()
            diff_df['sandbox_data'] = sandbox[key].loc[values].tolist()
            if diff_df.empty == False:
                diff_df['dirt_data'] = diff_df[['real_data', 'sandbox_data']].apply(
                    lambda x: 'real_data : ' + str(x['real_data']) + ' , sandbox_data : ' + str(x['sandbox_data']),
                    axis=1)
                diff_df = diff_df.set_index('apply_risk_id')
                diff_df = pd.DataFrame(diff_df, dtype=str)
                diff[key].loc[values] = diff_df['dirt_data'].loc[values]

    diff.to_excel(writer, sheet_name='对比结果详情', index=True, encoding='gbk')

    # origin data
    #     df.to_excel(writer, sheet_name = 'real_data', index = True, encoding = 'gbk')
    #     sandbox.to_excel(writer, sheet_name = 'sandbox_data', index = True, encoding = 'gbk')
    #     oot.to_excel(writer, sheet_name = 'oot_data', index = True, encoding = 'gbk')

    #     Bscore: 评分清单数据
    Bscore = get_Bscore(model_id, strat_time, end_time)
    Bscore.to_excel(writer, sheet_name='评分数据清单', index=True, encoding='gbk')

    writer.save()
    writer.close()

    get_diff(df, sandbox, model_id, equipment_app_names_value)

    oot_score_df = pd.DataFrame(oot[y_pro_oot], columns=[y_pro_oot])
    oot_score = oot_score_df[y_pro_oot].map(lambda s: prob_to_score(s, A=A, B=72.14))
    simu_score = sandbox.score.convert_objects(convert_numeric=True)

    # plot normal distribution curve
    plot_normal_curve(simu_score, oot_score)
