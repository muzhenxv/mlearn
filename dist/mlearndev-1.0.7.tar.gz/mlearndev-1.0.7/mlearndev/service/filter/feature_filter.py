import pandas as pd
from sklearn.feature_selection import *
from ..data_service import get_data
import numpy as np
from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.linear_model import *
from sklearn.tree import *
from sklearn.ensemble import *
from xgboost.sklearn import XGBClassifier

class FeatureFilter(BaseEstimator, TransformerMixin):
    def __init__(self, method, params):
        self.method = method
        self.params = params
        if 'score_func' in self.params:
            self.params['score_func'] = eval(self.params['score_func'])
        else:
            self.params['estimator'] = eval(self.params['estimator']['estimator'])(**self.params['estimator']['params'])

    def fit(self, df_src, label):
        self.label = label
        df = get_data(df_src)
        df.fillna(-999, inplace=True)
        label = df.pop(label)
        if self.method == 'SelectKBest':
            if self.params['k'] > df.shape[1]:
                self.params['k'] = 'all'
        elif self.method == 'RFE':
            if self.params['n_features_to_select'] > df.shape[1]:
                self.params['n_features_to_select'] = df.shape[1]
        self.enc = eval(self.method)(**self.params)

        self.columns = list(df.columns)

        self.enc.fit(df, label)
        return self

    def transform(self, df_src):
        df = get_data(df_src)
        df.fillna(-999, inplace=True)
        try:
            df_label = df.pop(self.label)
        except:
            df_label = pd.DataFrame()

        if list(df.columns) != self.columns:
            c = [c for c in self.columns if c not in df.columns]
            raise ValueError(f'Unexpected columns {c} are found!')

        df_final = pd.DataFrame(self.enc.transform(df))
        df_final.columns = np.array(self.columns)[self.enc.get_support()]

        df_final.index = df.index
        df_final = pd.concat([df_final, df_label], axis=1)
        df_final.replace(-999, np.nan, inplace=True)
        return df_final
