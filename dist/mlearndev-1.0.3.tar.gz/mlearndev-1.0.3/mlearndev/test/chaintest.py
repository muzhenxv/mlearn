import json
from ..interface import *
from .set_params import set_params


def chaintest(test_path, label='01d', dst='~/dev/flow_0/', time_col='apply_risk_created_at', index_col='apply_risk_id',
              label_col='overdue_days', cate_dict='~/repo/mlearn/mlearndev/materials/cate_dict_20180806_v1.pkl', optimizer_f=True,
              app_f=False, custom_params=None):
    if cate_dict.startswith('~/'):
        cate_dict = os.environ['HOME'] + '/' + cate_dict.split('/', 1)[1]

    if custom_params is None:
        dic_params = set_params(
            test_path, label, dst, time_col, index_col, label_col, cate_dict, optimizer_f, app_f)
    else:
        dic_params = custom_params

    spliter_ui(json.dumps(dic_params['spliter']))

    transformer_ui(json.dumps(dic_params['transformer']))

    filter_ui(json.dumps(dic_params['filter']))

    if optimizer_f:
        optimizer_ui(json.dumps(dic_params['optimizer']))

    trainer_ui(json.dumps(dic_params['trainer']))

    return None
