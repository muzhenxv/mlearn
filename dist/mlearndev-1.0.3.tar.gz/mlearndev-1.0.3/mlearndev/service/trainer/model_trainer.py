from .cv_trainer import base_model_evaluation
from ..data_service import get_data
import xgboost as xgb
import pandas as pd


class ModelTrainer:
    def __init__(self, method, params, n_folds=5, test_size=0.2, random_state=7,
                 verbose=True, oversample=False):
        self.method = method
        self.params = params
        self.n_folds = n_folds
        self.test_size = test_size
        self.random_state = random_state
        self.verbose = verbose
        self.oversample = oversample

    def fit(self, df_src, label):
        self.label = label
        df = get_data(df_src)
        target = df.pop(self.label)

        params = self.params.copy()

        self.enc, df_cv, df_test, df_val, df_train = base_model_evaluation(df, target, self.method, params,
                                                                           self.n_folds,
                                                                           self.test_size, self.random_state,
                                                                           self.oversample, self.verbose)
        self.columns = list(df.columns)
        return self.enc, df_cv, df_test, df_val, df_train

    def transform(self, df_src):
        df = get_data(df_src)

        try:
            df_label = df.pop(self.label)
            df_label.name = 'y_true'
        except:
            df_label = pd.DataFrame()

        df = df[self.columns]

        pred = self.enc.predict_proba(df)[:, 1]

        df_final = pd.DataFrame(pred, columns=['y_pred'])
        df_final.index = df.index
        df_final = pd.concat([df_final, df_label], axis=1)
        return df_final
