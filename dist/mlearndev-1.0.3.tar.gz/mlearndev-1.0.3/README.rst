```
import os

import sys

sys.path.append('/Users/muzhen/repo/mlearn')

import mlearndev as mlearn

import pandas as pd

import json

import pickle

test_path = '/Users/muzhen/dev/flow_0/datasource/fixed_platform_v4_2.csv'

mlearn.chaintest(test_path)
```
