import pandas as pd
import numpy as np
from collections import Counter
from collections import defaultdict
import os
from pandas.api.types import is_numeric_dtype


def get_max_same_count(c):
    try:
        return c.value_counts().iloc[0]
    except:
        return len(c)


def desc_df(df_origin):
    df = df_origin.copy()

    df_desc = pd.DataFrame(df.isnull().sum(axis=0), columns=['null_num'])
    df_desc['notnull_num'] = df.shape[0] - df_desc['null_num']
    df_desc['notnull_ratio'] = df_desc['notnull_num'] / df.shape[0]

    nunique_value = df.apply(lambda c: c.nunique())
    df_desc['diff_values_num'] = nunique_value

    same_value = df.apply(get_max_same_count)
    df_desc['most_value_num'] = same_value
    df_desc['same_ratio'] = same_value / df.shape[0]

    return df_desc


def cover_stats(df, feature_map_dict=None):
    data_fg_r = (df.notnull().sum(axis=1) > 0).sum() / df.shape[0]

    t = desc_df(df)
    t = t[['notnull_ratio']]
    t.columns = ['覆盖率']

    t['饱和度'] = t['覆盖率'] / data_fg_r
    if feature_map_dict:
        t.index = pd.MultiIndex.from_tuples([(i, feature_map_dict[i]) for i in t.index])
        t1 = pd.DataFrame(columns=['覆盖率', '饱和度'])
        t1.ix[('dataset', '数据集'),] = [data_fg_r, np.nan]
        t = pd.concat([t1, t], axis=0)
    else:
        t1 = pd.DataFrame(columns=['覆盖率', '饱和度'])
        t1.loc['数据集'] = [data_fg_r, np.nan]
        t = pd.concat([t1, t], axis=0)

    return t


def target_stats(df_origin, target_col, time_col):
    dic = {}
    df = df_origin.copy()
    dic[target_col] = df[target_col].astype(int).mean()
    dic[f'{time_col}_start'] = df[time_col].min()
    dic[f'{time_col}_end'] = df[time_col].max()
    dic['sample_num'] = df.shape[0]

    return dic


def get_freq_stats(df):
    t = df.astype(str).describe().T
    t['freq_ratio'] = t['freq'] / t['count']
    return t


def get_desc_stats(df):
    if not df.dtypes.map(is_numeric_dtype).any():
        return pd.DataFrame(columns=['count', 'mean', 'std', 'min', '25%', '50%', '75%', 'max'])
    return df.describe().T


def get_missing_stats(df):
    saturation_ratio = (df.notnull().sum(axis=1) > 0).sum() / df.shape[0]
    t = pd.DataFrame(df.isnull().mean(), columns=['missing'])
    t['cover'] = 1 - t['missing']
    t['saturation'] = t['cover'] / saturation_ratio
    return t


def _series_distribution_stats(dfs, cate_convert_thr=20, cate_thr=20, cont_thr=20, cont_low_percent=5,
                               cont_high_percent=95):
    print('start', dfs.name, '--------------')
    if (not is_numeric_dtype(dfs)) | (dfs.nunique() < cate_convert_thr):
        if (dfs.nunique() < cate_convert_thr):
            tmp = dfs.value_counts()
        else:
            tmp = dfs.value_counts()[:cate_thr]
            tmp['others+'] = dfs.value_counts()[cate_thr:].sum()
        null_num = dfs.isnull().sum()
        if null_num > 0:
            tmp.ix['missing'] = null_num
    else:
        t = dfs[dfs.notnull() & (dfs != np.inf) & (dfs != -np.inf)]

        low_thr = np.percentile(t, q=cont_low_percent)
        high_thr = np.percentile(t, q=cont_high_percent)
        min_thr = t.min()
        max_thr = t.max()

        t2 = t[(t > low_thr) & (t < high_thr)]

        if t2.shape[0] > 0:
            tmp = pd.cut(t2, bins=cont_thr).value_counts().sort_index()
            tmp.index = tmp.index.categories.to_native_types().astype(object)
        else:
            tmp = pd.Series(name=dfs.name)

        null_num = dfs.isnull().sum()
        inf_num = (dfs == np.inf).sum()
        neg_inf_num = (dfs == -np.inf).sum()

        low_num = (t <= low_thr).sum()
        high_num = (t >= high_thr).sum()

        if low_num > 0:
            pd.Series(low_num, ['[%s,%s]' % (min_thr, low_thr)]).append(tmp)
        if neg_inf_num > 0:
            pd.Series(neg_inf_num, ['-inf']).apppend('tmp')
        if high_thr > 0:
            tmp.ix['[%s,%s]' % (high_thr, max_thr)] = high_num
        if inf_num > 0:
            tmp.ix['inf'] = inf_num
        if null_num > 0:
            tmp.ix['missing'] = null_num

    return tmp.to_json()


def distribution_stats(df, cate_convert_thr=20, cate_thr=20, cont_thr=20, cont_low_percent=5, cont_high_percent=95):
    t = pd.DataFrame(df.dtypes.astype(str), columns=['type'])
    t['distribution'] = np.nan
    for c in t.index:
        t.loc[c, 'distribution'] = _series_distribution_stats(df[c], cate_convert_thr=cate_convert_thr,
                                                              cate_thr=cate_thr, cont_thr=cont_thr,
                                                              cont_low_percent=cont_low_percent,
                                                              cont_high_percent=cont_high_percent)

    return t


def data_stats(df_origin, cate_cols=None, error='ignore'):
    df = df_origin.copy()
    if cate_cols:
        cols = [c for c in cate_cols if c in df.columns]
        error_cols = [c for c in cate_cols if c not in df.columns]
        if not error_cols:
            if error == 'ignore':
                print('-------', error_cols, 'are not in data!', '-----------------')
            elif error == 'raise':
                raise Exception('---------', error_cols, 'are not in data!', '----------')
            else:
                raise KeyError('error params must be "ignore" or "raise"')

        df['cols'] = df[cols].astype(str)

    t0 = df.dtypes.astype(str)
    t0.name = 'type'
    t1 = get_freq_stats(df)
    t2 = get_desc_stats(df)
    del t2['count']
    t3 = get_missing_stats(df)
    t4 = distribution_stats(df)
    del t4['type']
    t = pd.concat([t0, t1, t2, t3, t4], axis=1)
    return t
