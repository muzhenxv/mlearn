import pandas as pd
import numpy as np
import json
import os
import sys
from ..transformer.continous_encoding import *
from ..transformer.category_encoding import *
# from ..transformer.custom_encoding import  AppCateEncoder, BaseEstimator, TransformerMixin, Counter,
from ..transformer.base_encoding import *
from ..transformer.feature_gen import *

def get_max_same_count(c):
    try:
        return c.value_counts().iloc[0]
    except:
        return len(c)


def get_same_value_ratio(df):
    t = df.apply(get_max_same_count) / df.shape[0]
    t.name = 'same_value'
    return t


def get_missing_value_ratio(df):
    t = df.isnull().mean()
    t.name = 'missing'
    return t


def convert_df_type(df, threshold=5, retsize=False):
    df = df.apply(pd.to_numeric, errors='ignore')
    cols = df.nunique()[df.nunique() < threshold].index.values
    df[cols] = df[cols].astype(str)

    cate_cols = df.select_dtypes(include=['object'])
    cont_cols = df.select_dtypes(exclude=['object'])
    # bool convert to int by producting 1
    df[cont_cols] = df[cont_cols] * 1
    if retsize:
        feature_size = df[cate_cols].nunique().sum() + len(cont_cols)
        return df, feature_size
    return df

def instantiate(method, method_params=None):
    try:
        enc = eval(method)(**method_params)
    except:
        if method.endswith('.py'):
            path = method
        else:
            path = os.path.dirname(get_rootpath()) + '/udf/' + method + '.py'
        print(path)
        dirpath = os.path.dirname(path)
        classname = os.path.basename(path).split('.')[0]
        sys.path.append(dirpath)

        mod = __import__(classname)
        enc = getattr(mod, classname, None)(**method_params)

    return enc

def get_rootpath():
    path = os.path.realpath(__file__)
    subpath = path.split('mlearn', 1)[0] + 'mlearn/'
    if os.path.exists(subpath + 'mlearn'):
        utilspath = subpath + 'mlearn'
    else:
        utilspath = subpath + 'mlearndev'
    return utilspath