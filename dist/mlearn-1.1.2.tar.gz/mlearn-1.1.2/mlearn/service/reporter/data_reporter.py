import pandas as pd
import numpy as np
import os
from .visualize import feature_plot, eva_plot
from . import feature_evaluation
from .feature_explore import *
import simplejson
from itertools import chain
from collections import defaultdict
from ..monitor import data_monitor as dm
import pickle
import traceback
from ..base_utils import *
from ...service.base_utils import *
from ..data_service import get_data


# TODO: report各函数df_test应该作为可选参数

def sampler_report(sample_num, dic, group_ratio, report_dst):
    """
    报告分组基准，分组前后样本分布对比
    :param sample_num:
    :param dic:
    :param group_ratio:
    :param report_dst:
    :return:
    """
    simplejson.dump(sample_num, open(os.path.join(report_dst, 'sample_num.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)
    simplejson.dump(dic, open(os.path.join(report_dst, 'dic.json'), 'w'), ignore_nan=True, cls=simplejsonEncoder)
    simplejson.dump(group_ratio, open(os.path.join(report_dst, 'group_ratio.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)


def spliter_report(X_train, X_test, time_col, label_col, report_dst):
    """
    覆盖率、饱和度统计，数据描述性统计和直方图，目标分布统计
    :param df_train:
    :param df_test:
    :param time_col:
    :param label_col:
    :param report_dst:
    :return:
    """
    df_train = X_train.copy()
    df_test = X_test.copy()
    # TODO: 等待删除，暂时前端需要该输出
    c_tr = cover_stats(df_train)
    c_te = cover_stats(df_test)
    c_tr.to_pickle(os.path.join(report_dst, 'c_tr.pkl'))
    c_te.to_pickle(os.path.join(report_dst, 'c_te.pkl'))

    dic = {'train': table_to_dict(c_tr), 'test': table_to_dict(c_te)}
    simplejson.dump(dic, open(os.path.join(report_dst, 'cover_stats.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)

    c_tr = data_stats(df_train)
    c_te = data_stats(df_test)
    # c_tr.to_pickle(os.path.join(report_dst, 's_tr.pkl'))
    # c_te.to_pickle(os.path.join(report_dst, 's_te.pkl'))
    df = merge_multi_df({'train': c_tr, 'test': c_te}, axis=0)
    df.to_pickle(os.path.join(report_dst, 'data_stats.report'))
    dic = {'train': table_to_dict(c_tr), 'test': table_to_dict(c_te)}
    simplejson.dump(dic, open(os.path.join(report_dst, 'data_stats.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)

    d_tr = target_stats(df_train, label_col, time_col)
    d_te = target_stats(df_test, label_col, time_col)
    dic = {'train': d_tr, 'test': d_te}
    df = pd.DataFrame(dic).T
    df.to_pickle(os.path.join(report_dst, 'target_stats.report'))
    simplejson.dump(dic, open(os.path.join(report_dst, 'target_stats.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)

    del df_train[time_col], df_test[time_col]

    wr = feature_evaluation.WOEReport()
    d_tr = wr.fit_transform(df_train, label_col)
    d_te = wr.transform(df_test, label_col)
    df = merge_multi_df({'train': d_tr, 'test': d_te}, axis=1)
    df.to_pickle(os.path.join(report_dst, 'woe_stats.report'))
    # d_tr.to_csv(os.path.join(report_dst, 'woe_stats.csv'))
    # d_te.to_csv(os.path.join(report_dst, 'woe_stats_te.csv'))


def transformer_report(df_train, df_test, label, report_dst):
    """
    单变量分析、直方排序图分析、train/test特征一致性分布分析
    :param df_train:
    :param df_test:
    :param label:
    :param report_dst:
    :return:
    """
    df_train_cp = df_train.copy()
    df_test_cp = df_test.copy()
    df_train.fillna(-999, inplace=True)
    train_plot_data = feature_plot(df_train, label, path=os.path.join(report_dst, 'train_feature_plot.png'))

    res = feature_evaluation.feature_evaluation(df_train, [label])
    res.to_pickle(report_dst + '/eva.pkl')
    res.to_csv(os.path.join(report_dst, 'train_feature_indices.csv'))
    train_data = res.copy()
    train_text = table_to_dict(res)
    if df_test is not None:
        df_test.fillna(-999, inplace=True)
        test_plot_data = feature_plot(df_test, label, path=os.path.join(report_dst, 'test_feature_plot.png'))

        res = feature_evaluation.feature_evaluation(df_test, [label])
        res.to_csv(os.path.join(report_dst, 'test_feature_indices.csv'))
        test_data = res.copy()
        test_text = table_to_dict(res)

    df = merge_multi_df({'train': train_data, 'test': test_data}, axis=1)
    df.to_pickle(os.path.join(report_dst, 'feature_indices.report'))

    text = {'train': train_text, 'test': test_text}
    simplejson.dump(text, open(os.path.join(report_dst, 'feature_indices.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)

    train_plot_data = {k: {'train': v} for k, v in train_plot_data.items()}
    test_plot_data = {k: {'test': v} for k, v in test_plot_data.items()}
    plot_data = defaultdict(dict)
    for k, v in chain(train_plot_data.items(), test_plot_data.items()):
        plot_data[k].update(v)
    simplejson.dump(plot_data, open(os.path.join(report_dst, 'plot_data.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)

    dic, mcc, weights = dm.consistent_dataset_test(df_train_cp, df_test_cp, label, report_dst=None,
                                                   covariate_shift_eva=True)
    stable_test = {'single_feature_test': dic, 'mcc': mcc}
    simplejson.dump(stable_test, open(os.path.join(report_dst, 'stable_test.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)
    pickle.dump(weights, open(os.path.join(report_dst, 'weights.pkl'), 'wb'))

    t = pd.DataFrame(dic).T
    t = pd.concat([t, pd.DataFrame({'mcc': {'All_Dataset': mcc}})], axis=0)
    t.to_pickle(os.path.join(report_dst, 'stable_test.report'))

    wr = feature_evaluation.WOEReport()
    d_tr = wr.fit_transform(df_train, label)
    d_te = wr.transform(df_test, label)
    df = merge_multi_df({'train': d_tr, 'test': d_te}, axis=1)
    df.to_pickle(os.path.join(report_dst, 'woe_stats.report'))


def filter_report(enc, report_dst):
    """
    过滤指标得分输出
    :param enc:
    :param score_func:
    :param report_dst:
    :return:
    """
    data = {}
    for encoder_dict in enc.st:
        df = encoder_dict['enc'].features_report
        data[encoder_dict['method']] = table_to_dict(df)

    simplejson.dump(data, open(os.path.join(report_dst, 'feature_indices.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)

    df = pd.DataFrame()
    for encoder_dict in enc.st:
        t = encoder_dict['enc'].features_report
        t.columns = pd.MultiIndex.from_product([[encoder_dict['method']], t.columns])
        df = pd.concat([df, t], axis=1)

    t = pd.Series(True, index=df.index)
    for c in df.columns:
        if c[-1].endswith('_support'):
            t = t & df[c]

    df['final_supprt'] = t

    df.to_pickle(os.path.join(report_dst, 'feature_filter.report'))


def optimizer_report(all_df, report_dst):
    """
    每轮迭代参数和效果的输出
    :param all_df:
    :param report_dst:
    :return:
    """
    # all_df.to_csv(os.path.join(report_dst, 'all_params_result.csv'))
    all_df.to_pickle(os.path.join(report_dst, 'optimizer_result.report'))
    """
    Currently (as of Pandas version 0.18), df.to_dict('records') accesses the NumPy array df.values. 
    This property upcasts the dtype of the int column to float so that the array can have a single common dtype. 
    After this point there is no hope of returning the desired result -- all the ints have been converted to floats.
    refers: https://stackoverflow.com/questions/37897527/get-python-pandas-to-dict-with-orient-records-but-without-float-cast
    """
    dic = [{col: getattr(row, col) for col in all_df} for row in all_df.itertuples()]
    simplejson.dump(dic, open(os.path.join(report_dst, 'all_params_result.json'), 'w'), ignore_nan=True,
                    cls=simplejsonEncoder)


# def trainer_report(enc, df_train, df_val, df_test, test_m, report_dst):
#     """
#     训练报告
#     :param enc:
#     :param df_train:
#     :param df_val:
#     :param df_test:
#     :param test_m:
#     :param report_dst:
#     :return:
#     """
#     rr = feature_evaluation.ResultReport()
#     rr.fit(df_train.y_pred)
#     df = rr.transform({'train': df_train, 'val': df_val, test_m: df_test})
#     df.to_pickle(os.path.join(report_dst, 'level_report.report'))
#     pickle.dump(rr, open(os.path.join(report_dst, 'rr_enc.pkl'), 'wb'))
#
#     eval_plot_path = os.path.join(report_dst, 'trainer_eva_report.png')
#     dic_all = eva_plot({'train': [df_train.y_true, df_train.y_pred], 'val': [df_val.y_true, df_val.y_pred],
#                         test_m: [df_test.y_true, df_test.y_pred]}, path=eval_plot_path)
#     import re
#     from collections import defaultdict
#     dic = defaultdict(dict)
#     token = re.compile('[\d.]+')
#     for k in dic_all['roc_curve']:
#         for v in dic_all['ks_curve'][k]:
#             if v.startswith('KS'):
#                 s = float(re.findall(token, v)[0])
#                 #             dic[k].append({'ks': s})
#                 dic[k]['ks'] = s
#     for v in dic_all['roc_curve']['train'].keys():
#         k1, k2 = v.split('(')
#         k1 = k1.strip()
#         s = float(re.findall(token, k2)[0])
#         #     dic[k1].append({'auc': s})
#         dic[k1]['auc'] = s
#     # df = pd.DataFrame.from_dict(dic)
#     simplejson.dump(dict(dic), open(os.path.join(report_dst, 'abstract_data.json'), 'w'), ignore_nan=True,
#                     cls=simplejsonEncoder)
#     simplejson.dump(dic_all, open(os.path.join(report_dst, 'eva_data.json'), 'w'), ignore_nan=True,
#                     cls=simplejsonEncoder)
#
#     pd.DataFrame(dic).T.to_pickle(os.path.join(report_dst, 'abstract_data.report'))
#
#     importances = getattr(enc.enc, "feature_importances_", None)
#     coef_ = getattr(enc.enc, "coef_", None)
#     rules_ = getattr(enc.enc, "rules_", None)
#     if not (importances is None and coef_ is None):
#         try:
#             df_features = \
#                 pd.DataFrame({'feature_names': enc.columns, 'feature_importances': get_feature_importances(enc.enc)})[
#                     ['feature_names', 'feature_importances']]
#         except Exception as e:
#             print(traceback.format_exc())
#             df_features = pd.DataFrame()
#     elif rules_ is not None:
#         try:
#             df_features = pd.DataFrame({'rules': enc.enc.rule})
#         except Exception as e:
#             print(traceback.format_exc())
#             df_features = pd.DataFrame()
#     else:
#         df_features = pd.DataFrame()
#
#     simplejson.dump(df_features.to_dict(orient='records'),
#                     open(os.path.join(report_dst, 'feature_importances.json'), 'w'), ignore_nan=True,
#                     cls=simplejsonEncoder)
#
#     pd.DataFrame(df_features).to_pickle(os.path.join(report_dst, 'feature_importances.report'))
#
#     report_dst = os.path.dirname(report_dst)
#     merge_excel(os.path.dirname(report_dst), os.path.join(os.path.dirname(report_dst), 'all_report.xlsx'))
#     return

def trainer_report(enc, df_train, df_val, test_src, test_data_dst, report_dst):
    """
    训练报告
    :param enc:
    :param df_train:
    :param df_val:
    :param df_test:
    :param test_m:
    :param report_dst:
    :return:
    """
    if test_src is not None:
        df_test = enc.transform(test_src)
        df_test.to_pickle(test_data_dst)
        test_m = 'oot'
    else:
        test_m = 'test'

    df = get_data(test_src)

    try:
        df_label = df.pop(enc.label)
        df_label.name = 'y_true'
    except:
        df_label = pd.DataFrame()

    if enc.enc._estimator_type == 'ruler':
        tmp = enc.enc.get_metrics(df, df_label)
        tmp.to_pickle(os.path.join(report_dst, 'rule_report.report'))
        tmp = table_to_dict(tmp)
        simplejson.dump(tmp, open(os.path.join(report_dst, 'rule_report.json'), 'w'), ignore_nan=True,
                        cls=simplejsonEncoder)

    try:
        rr = feature_evaluation.ResultReport()
        rr.fit(df_train.y_pred)
        df = rr.transform({'train': df_train, 'val': df_val, test_m: df_test})
        df.to_pickle(os.path.join(report_dst, 'level_report.report'))
        pickle.dump(rr, open(os.path.join(report_dst, 'rr_enc.pkl'), 'wb'))

        eval_plot_path = os.path.join(report_dst, 'trainer_eva_report.png')
        dic_all = eva_plot({'train': [df_train.y_true, df_train.y_pred], 'val': [df_val.y_true, df_val.y_pred],
                            test_m: [df_test.y_true, df_test.y_pred]}, path=eval_plot_path)
        import re
        from collections import defaultdict
        dic = defaultdict(dict)
        token = re.compile('[\d.]+')
        for k in dic_all['roc_curve']:
            for v in dic_all['ks_curve'][k]:
                if v.startswith('KS'):
                    s = float(re.findall(token, v)[0])
                    #             dic[k].append({'ks': s})
                    dic[k]['ks'] = s
        for v in dic_all['roc_curve']['train'].keys():
            k1, k2 = v.split('(')
            k1 = k1.strip()
            s = float(re.findall(token, k2)[0])
            #     dic[k1].append({'auc': s})
            dic[k1]['auc'] = s
        # df = pd.DataFrame.from_dict(dic)
        simplejson.dump(dict(dic), open(os.path.join(report_dst, 'abstract_data.json'), 'w'), ignore_nan=True,
                        cls=simplejsonEncoder)
        simplejson.dump(dic_all, open(os.path.join(report_dst, 'eva_data.json'), 'w'), ignore_nan=True,
                        cls=simplejsonEncoder)

        pd.DataFrame(dic).T.to_pickle(os.path.join(report_dst, 'abstract_data.report'))

        importances = getattr(enc.enc, "feature_importances_", None)
        coef_ = getattr(enc.enc, "coef_", None)
        rules_ = getattr(enc.enc, "rules_", None)
        if not (importances is None and coef_ is None):
            try:
                df_features = \
                    pd.DataFrame(
                        {'feature_names': enc.columns, 'feature_importances': get_feature_importances(enc.enc)})[
                        ['feature_names', 'feature_importances']]
            except Exception as e:
                print(traceback.format_exc())
                df_features = pd.DataFrame()
        elif rules_ is not None:
            try:
                df_features = pd.DataFrame({'rules': enc.enc.rules_})
            except Exception as e:
                print(traceback.format_exc())
                df_features = pd.DataFrame()
        else:
            df_features = pd.DataFrame()

        simplejson.dump(df_features.to_dict(orient='records'),
                        open(os.path.join(report_dst, 'feature_importances.json'), 'w'), ignore_nan=True,
                        cls=simplejsonEncoder)

        pd.DataFrame(df_features).to_pickle(os.path.join(report_dst, 'feature_importances.report'))
    except Exception as e:
        print(traceback.format_exc())

    report_dst = os.path.dirname(report_dst)
    merge_excel(os.path.dirname(report_dst), os.path.join(os.path.dirname(report_dst), 'all_report.xlsx'))
    return
