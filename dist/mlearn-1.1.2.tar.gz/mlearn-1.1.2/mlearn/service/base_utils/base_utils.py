import simplejson
import pandas as pd
import numpy as np
import json
import os


def convert_df_type(df, threshold=5, retsize=False):
    """
    dataframe 判断特征类型。首先根据类型判断，然后对数值型做附加判断
    :param df:
    :param threshold: 取值数小于thr，视为离散。
    :param retsize:
    :return:
    """
    df = df.apply(pd.to_numeric, errors='ignore')
    cols = df.nunique()[df.nunique() < threshold].index.values
    df[cols] = df[cols].astype(str)

    cate_cols = df.select_dtypes(include=['object'])
    cont_cols = df.select_dtypes(exclude=['object'])
    # bool convert to int by producting 1
    df[cont_cols] = df[cont_cols] * 1
    if retsize:
        feature_size = df[cate_cols].nunique().sum() + len(cont_cols)
        return df, feature_size
    return df


def get_feature_importances(estimator, norm_order=1):
    """
    由于此处对于线模型，直接使用系数绝对值作为特征重要性的度量指标。因此对于线模型，需要要求入模特征标准化
    :param estimator:
    :param norm_order:
    :return:
    """
    """Retrieve or aggregate feature importances from estimator"""
    importances = getattr(estimator, "feature_importances_", None)

    coef_ = getattr(estimator, "coef_", None)
    if importances is None and coef_ is not None:
        if estimator.coef_.ndim == 1:
            importances = np.abs(coef_)

        else:
            importances = np.linalg.norm(coef_, axis=0,
                                         ord=norm_order)

    elif importances is None:
        raise ValueError(
            "The underlying estimator %s has no `coef_` or "
            "`feature_importances_` attribute. Either pass a fitted estimator"
            " to SelectFromModel or call fit before calling transform."
            % estimator.__class__.__name__)

    return importances


def table_to_dict(df):
    try:
        df.columns = df.columns.levels[0]
    except:
        pass
    df.index.name = 'feature'
    df = df.reset_index()
    return df.to_dict(orient='records')


def merge_multi_df(dic, axis=1, sort_f=True):
    l = []
    for k, v in dic.items():
        tmp = pd.DataFrame(v)
        if axis == 1:
            d_tr_t = tmp.T
            d_tr_t['dataset'] = k
            d_tr_t = d_tr_t.set_index('dataset', append=True)
            tmp = d_tr_t.T
        else:
            tmp['dataset'] = k
            tmp = tmp.set_index('dataset', append=True)
        l.append(tmp)
    t = pd.concat(l, axis=axis)
    if sort_f:
        t = t.sort_index(axis=axis, ascending=False)

    return t


def merge_excel(report_src, report_dst):
    writer = pd.ExcelWriter(report_dst)
    for root, dirs, files in os.walk(report_src):
        if root != report_src:
            for file in files:
                if file.endswith('report'):
                    path = os.path.join(root, file)
                    sheetname = os.path.basename(os.path.dirname(root)) + '_' + file[:-7]
                    df = pd.read_pickle(path)
                    df.to_excel(writer, sheet_name=sheetname,
                                encoding='gbk')
                if file.startswith('level_report'):
                    workbook = writer.book
                    worksheet = writer.sheets[sheetname]
                    worksheet.insert_image('B18', os.path.join(report_src, 'trainer/report/trainer_eva_report.png'))
    df = pd.DataFrame()
    df.to_excel(writer, sheet_name='transformer_feature_plot')
    workbook = writer.book
    worksheet = writer.sheets['transformer_feature_plot']
    worksheet.insert_image('B02', os.path.join(report_src, 'transformer/report/train_feature_plot.png'),
                           {'x_scale': 0.5, 'y_scale': 0.5})
    worksheet.insert_image('S02', os.path.join(report_src, 'transformer/report/test_feature_plot.png'),
                           {'x_scale': 0.5, 'y_scale': 0.5})
    workbook.close()

    writer.save()
    writer.close()


class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)


class simplejsonEncoder(simplejson.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)
