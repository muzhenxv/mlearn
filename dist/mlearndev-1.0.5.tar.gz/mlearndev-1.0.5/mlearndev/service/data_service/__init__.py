from .dataservice import *

__all__ = ['get_data']