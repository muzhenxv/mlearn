import pandas as pd
from sklearn.feature_selection import *
from ..data_service import get_data
import numpy as np
from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.linear_model import *
from sklearn.tree import *
from sklearn.ensemble import *
from xgboost.sklearn import XGBClassifier
from ..monitor.data_monitor import *
from ..base_utils import *


class SklearnFilter(BaseEstimator, TransformerMixin):
    def __init__(self, method, params):
        self.method = method
        self.params = params
        if 'score_func' in self.params:
            self.indicator = self.params['score_func']
            self.params['score_func'] = eval(self.params['score_func'])
        elif 'estimator' in self.params:
            self.indicator = self.params['estimator']['estimator']
            self.params['estimator'] = eval(self.params['estimator']['estimator'])(**self.params['estimator']['params'])

        if 'n_features_to_select' in self.params:
            self.n_features_to_select = self.params['n_features_to_select']
            if self.method != 'RFE':
                self.params.pop('n_features_to_select')
        else:
            self.n_features_to_select = None

    def fit(self, X_train, y_train=None, X_test=None, y_test=None):
        """
        加入X_test,y_test是为了reweight时需要用到test集考虑
        :param X_train:
        :param y_train:
        :param X_test:
        :param y_test:
        :return:
        """
        df = X_train.copy()
        df.fillna(-999, inplace=True)
        label = y_train.copy()

        self.columns = list(df.columns)

        self.enc = eval(self.method)(**self.params)
        self.enc.fit(df, label)

        self.features_report = self._get_report(self.enc, self.columns, self.method, self.indicator)

        if self.n_features_to_select:
            self.selected_columns = list(self.features_report.index)[:self.n_features_to_select]
        else:
            self.selected_columns = list(self.features_report.index[self.features_report[self.indicator + '_support']])
        return self

    def transform(self, X_train):
        if list(X_train.columns) != self.columns:
            c = [c for c in self.columns if c not in df.columns]
            raise ValueError(f'Unexpected columns {c} are found!')

        df_final = X_train[self.selected_columns]
        return df_final

    def fit_transform(self, X_train, y_train=None, X_test=None, y_test=None):
        return self.fit(X_train, y_train, X_test, y_test).transform(X_train)

    @staticmethod
    def _get_report(enc, columns, method, indicator=''):
        df = pd.DataFrame(columns, columns=['feature_name'])
        if method == 'SelectKBest':
            df[indicator + '_support'] = enc.get_support()
            df[indicator + '_pvalues'] = enc.pvalues_
            df[indicator + '_scores'] = enc.scores_
            df = df.sort_values(indicator + '_pvalues', ascending=True)
        elif method == 'RFE':
            df[indicator + '_support'] = enc.get_support()
            df[indicator + '_ranking'] = enc.ranking_
            df[indicator + '_feature_importances'] = np.nan
            df[indicator + '_feature_importances'][enc.get_support()] = get_feature_importances(enc.estimator_)
            df = df.sort_values(indicator + '_feature_importances', ascending=False)
        elif method == 'SelectFromModel':
            df[indicator + '_support'] = enc.get_support()
            df[indicator + '_feature_importances'] = get_feature_importances(enc.estimator_)
            df = df.sort_values(indicator + '_feature_importances', ascending=False)
        df = df.set_index('feature_name')
        return df


class StableFilter(BaseEstimator, TransformerMixin):
    """
    特征稳定性判断，基于稳定性筛选
    """

    def __init__(self, indice_name='psi', indice_thr=0.2):
        self.indice_name = indice_name
        self.indice_thr = indice_thr

    def fit(self, X_train, y_train=None, X_test=None, y_test=None):
        dic, mcc, weights = consistent_dataset_test(X_train, X_test)
        df = pd.DataFrame(dic).T
        indice_col = df.columns[df.columns.astype(str).str.startswith(self.indice_name)][0]
        self.exclude_cols = list(df.index[df[indice_col] > self.indice_thr])
        self.features_report = df
        return self

    def transform(self, X_train):
        return X_train.drop(self.exclude_cols, axis=1)

    def fit_transform(self, X_train, y_train=None, X_test=None, y_test=None):
        return self.fit(X_train, y_train, X_test, y_test).transform(X_train)


from sklearn.feature_selection.rfe import if_delegate_has_method
from sklearn.feature_selection.rfe import clone
from sklearn.feature_selection import RFE
import statsmodels.api as sm

class RFEFilter(RFE):
    """Feature ranking with recursive feature elimination.
    """

    def __init__(self, estimator, n_features_to_select=None, step=1, verbose=0, alpha=0.05, by='coef', stepwise=False):
        # TODO: 改成**kwargs入参
        super().__init__(estimator, step=step, verbose=verbose,
                         n_features_to_select=n_features_to_select)
        self.n_features_to_select = self.n_features_to_select
        self.by = by
        self.stepwise = stepwise
        self.alpha = alpha

    def fit(self, X, y):
        self.meta_columns = X.columns.tolist()
        self.support_ = np.array([True for col in self.meta_columns])

        if self.by == 'coef':
            return self._fit_by_coef(X, y)
        elif self.by == 'stepwise':
            return self._fit_by_stepwise(X, y, n_features_to_select=self.n_features_to_select, alpha=self.alpha)
        elif self.by == 'stepwise_coef':
            self._fit_by_stepwise(X, y, n_features_to_select=self.n_features_to_select, alpha=self.alpha)
            return self._fit_by_coef(self._transform(X), y)
        else:
            return self._fit(X, y)

    def _fit_by_coef(self, X, y):
        # X_copy = X[self.features_selected]
        # X_copy = self._transform(X)
        X_copy = X.copy()
            
        # TODO : fit多次，取coef的平均值来度量是否要删除该特征
        # 是否需要指定
        self.estimator_ = clone(self.estimator)
        self.estimator_.fit(X_copy, y)
        self.coef_map = dict(zip(X_copy.columns.tolist(), list(self.estimator_.coef_[0])))

        # Elimination by estimator coeffication
        while np.sum(self.estimator_.coef_ < 0) > 0:
            # 特殊情况需要考虑
            self.features_selected = [k for k, v in self.coef_map.items() if v > 0]
            X_copy = X_copy[self.features_selected]
            self.estimator_.fit(X_copy, y)
            self.coef_map = dict(zip(X_copy.columns.tolist(), list(self.estimator_.coef_[0])))

        self.support_ = np.array([True if col in self.coef_map.keys() else False for col in self.meta_columns])
        return self
    
    
    def _fit_by_stepwise(self, X, y, n_features_to_select=None, alpha=0.05, lr_type='logistic'):
        # TODO : 
        if n_features_to_select is None:
            n_features_to_select = X.shape[1]

        remaining = set(X.columns)
        selected = []
        exclude_cols = []
        current_score = 0
        best_new_score = 0
        while remaining and best_new_score <= alpha and len(selected) < n_features_to_select:
            scores_with_candidates = []
            for candidate in remaining:
                if candidate in exclude_cols:
                    continue
                x_candidates = selected + [candidate]
                try:
                    if lr_type == 'logistic':
                        model_stepwise_forward = sm.Logit(y, X[x_candidates]).fit(disp=False)
                    elif lr_type == 'linear':
                        model_stepwise_forward = sm.OLS(y, X[x_candidates]).fit(disp=False)
                    else:
                        raise ValueError(f'Unexpected model type {lr_type} are found!')
                except:
                    exclude_cols.append(candidate)
                    x_candidates.remove(candidate)
                    continue
                score = model_stepwise_forward.pvalues[candidate]
                scores_with_candidates.append((score, candidate))

            scores_with_candidates.sort(reverse=True)
            best_new_score, best_candidate = scores_with_candidates.pop()
            if best_new_score <= alpha:
                remaining.remove(best_candidate)
                selected.append(best_candidate)
                print(best_candidate + ' enters: pvalue: ' + str(best_new_score))
    
        if lr_type == 'logistic':
            model_stepwise_backford = sm.Logit(y, X[selected]).fit(disp=False)
        elif lr_type == 'linear':
            model_stepwise_backford = sm.OLS(y, X[selected]).fit(disp=False)
        else:
            raise ValueError(f'Unexpected model type {lr_type} are found!')

        for fea in selected:
            if model_stepwise_backford.pvalues[fea] > alpha:
                selected.remove(fea)
                print(fea + ' removed: pvalue: ' + str(model_stepwise_backford.pvalues[fea]))

        self.support_ = np.array([True if col in selected else False for col in self.meta_columns])
        return self 
    
    def _transform(self, X):
        # TODO: check support
        return X.loc[:, self.support_]
