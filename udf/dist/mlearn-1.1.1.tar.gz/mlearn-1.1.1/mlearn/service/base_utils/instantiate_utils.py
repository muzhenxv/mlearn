import pandas as pd
import numpy as np
import json
import os
import sys
from ..transformer.continous_encoding import *
from ..transformer.category_encoding import *
# from ..transformer.custom_encoding import  AppCateEncoder, BaseEstimator, TransformerMixin, Counter,
from ..transformer.base_encoding import *
from ..transformer.feature_gen import *
from ..filter.base_filter import *
from sklearn.feature_selection import *
import simplejson

def instantiate(method, method_params=None):
    """
    字符串形式类名的实例化
    :param method:
    :param method_params:
    :return:
    """
    try:
        enc = eval(method)(**method_params)
    except:
        if method.endswith('.py'):
            path = method
        else:
            path = os.path.dirname(get_rootpath()) + '/udf/' + method + '.py'
        print(path)
        dirpath = os.path.dirname(path)
        classname = os.path.basename(path).split('.')[0]
        sys.path.append(dirpath)

        mod = __import__(classname)
        enc = getattr(mod, classname, None)(**method_params)

    return enc

def get_rootpath():
    path = os.path.realpath(__file__)
    subpath = path.split('mlearn', 1)[0] + 'mlearn/'
    if os.path.exists(subpath + 'mlearn'):
        utilspath = subpath + 'mlearn'
    else:
        utilspath = subpath + 'mlearndev'
    return utilspath