import simplejson
import pandas as pd
import numpy as np
import json
import os


# def get_max_same_count(c):
#     try:
#         return c.value_counts().iloc[0]
#     except:
#         return len(c)
#
#
# def get_same_value_ratio(df):
#     t = df.apply(get_max_same_count) / df.shape[0]
#     t.name = 'same_value'
#     return t
#
#
# def get_missing_value_ratio(df):
#     t = df.isnull().mean()
#     t.name = 'missing'
#     return t


def convert_df_type(df, threshold=5, retsize=False):
    """
    dataframe 判断特征类型。首先根据类型判断，然后对数值型做附加判断
    :param df:
    :param threshold: 取值数小于thr，视为离散。
    :param retsize:
    :return:
    """
    df = df.apply(pd.to_numeric, errors='ignore')
    cols = df.nunique()[df.nunique() < threshold].index.values
    df[cols] = df[cols].astype(str)

    cate_cols = df.select_dtypes(include=['object'])
    cont_cols = df.select_dtypes(exclude=['object'])
    # bool convert to int by producting 1
    df[cont_cols] = df[cont_cols] * 1
    if retsize:
        feature_size = df[cate_cols].nunique().sum() + len(cont_cols)
        return df, feature_size
    return df


def get_feature_importances(estimator, norm_order=1):
    """Retrieve or aggregate feature importances from estimator"""
    importances = getattr(estimator, "feature_importances_", None)

    coef_ = getattr(estimator, "coef_", None)
    if importances is None and coef_ is not None:
        if estimator.coef_.ndim == 1:
            importances = np.abs(coef_)

        else:
            importances = np.linalg.norm(coef_, axis=0,
                                         ord=norm_order)

    elif importances is None:
        raise ValueError(
            "The underlying estimator %s has no `coef_` or "
            "`feature_importances_` attribute. Either pass a fitted estimator"
            " to SelectFromModel or call fit before calling transform."
            % estimator.__class__.__name__)

    return importances


def table_to_dict(df):
    try:
        df.columns = df.columns.levels[0]
    except:
        pass
    df.index.name = 'feature'
    df = df.reset_index()
    return df.to_dict(orient='records')


def merge_train_test_table(train_data, test_data, axis=1):
    d_tr = train_data.copy()
    d_te = test_data.copy()
    if axis == 1:
        # if not 'levels' in dir(d_tr.columns):
        #     d_tr_indice = [d_tr.columns, ['train']]
        #     d_te_indice = [d_te.columns, ['test']]
        # else:
        #     d_tr_indice = []
        #     d_te_indice = []
        #     for i in range(len(d_tr.columns.levels)):
        #         d_tr_indice.append(d_tr.columns.levels[i])
        #     for i in range(len(d_te.columns.levels)):
        #         d_te_indice.append(d_te.columns.levels[i])
        #     d_tr_indice.append(['train'])
        #     d_te_indice.append(['test'])
        # d_tr.columns = pd.MultiIndex.from_product(d_tr_indice)
        # d_te.columns = pd.MultiIndex.from_product(d_te_indice)
        # t = pd.concat([d_tr, d_te], axis=axis).sort_index(axis=axis, ascending=False)
        d_tr_t = d_tr.T
        d_tr_t['dataset'] = 'train'
        d_tr_t = d_tr_t.set_index('dataset', append=True)
        d_te_t = d_te.T
        d_te_t['dataset'] = 'test'
        d_te_t = d_te_t.set_index('dataset', append=True)
        d_tr = d_tr_t.T
        d_te = d_te_t.T
    else:
        # if not 'levels' in dir(d_tr.index):
        #     d_tr_indice = [d_tr.index, ['train']]
        #     d_te_indice = [d_te.index, ['test']]
        # else:
        #     d_tr_indice = []
        #     d_te_indice = []
        #     for i in range(len(d_tr.index.levels)):
        #         d_tr_indice.append(d_tr.index.levels[i])
        #     for i in range(len(d_te.index.levels)):
        #         d_te_indice.append(d_te.index.levels[i])
        #     d_tr_indice.append(['train'])
        #     d_te_indice.append(['test'])
        # d_tr.index = pd.MultiIndex.from_product(d_tr_indice)
        # d_te.index = pd.MultiIndex.from_product(d_te_indice)

        d_tr['dataset'] = 'train'
        d_tr = d_tr.set_index('dataset', append=True)
        d_te['dataset'] = 'test'
        d_te = d_te.set_index('dataset', append=True)

    t = pd.concat([d_tr, d_te], axis=axis).sort_index(axis=axis, ascending=False)

    return t


def merge_excel(report_src, report_dst):
    writer = pd.ExcelWriter(report_dst)
    for root, dirs, files in os.walk(report_src):
        if root != report_src:
            for file in files:
                if file.endswith('report'):
                    path = os.path.join(root, file)
                    df = pd.read_pickle(path)
                    df.to_excel(writer, sheet_name=os.path.basename(os.path.dirname(root)) + '_' + file[:-7],
                                encoding='gbk')
    writer.save()
    writer.close()


class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)


class simplejsonEncoder(simplejson.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)
