class custom_udf1:
    def __init__(self):
        pass

    def fit(self,s='test'):
        print(s)
        return s
