import pandas as pd
import numpy as np


def get_max_same_count(c):
    try:
        return c.value_counts().iloc[0]
    except:
        return len(c)


def get_same_value_ratio(df):
    t = df.apply(get_max_same_count) / df.shape[0]
    t.name = 'same_value'
    return t


def get_missing_value_ratio(df):
    t = df.isnull().mean()
    t.name = 'missing'
    return t


def convert_df_type(df, threshold=5, retsize=False):
    df = df.apply(pd.to_numeric, errors='ignore')
    cols = df.nunique()[df.nunique() < threshold].index.values
    df[cols] = df[cols].astype(str)

    cate_cols = df.select_dtypes(include=['object'])
    cont_cols = df.select_dtypes(exclude=['object'])
    # bool convert to int by producting 1
    df[cont_cols] = df[cont_cols] * 1
    if retsize:
        feature_size = df[cate_cols].nunique().sum() + len(cont_cols)
        return df, feature_size
    return df
