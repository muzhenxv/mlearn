from sklearn.model_selection import train_test_split
import os
from ..data_service import get_data
from ..reporter import spliter_report


def data_spliter(df_src, label, report_dst, time_col='biz_report_expect_at', index_col='apply_risk_id', label_col='overdue_days', test_size=0.2, method='oot', random_state=7):
    """

    :param df: dataframe
    :param by:
    :param test_size:
    :param method:
    :param random_state:
    :return:
    """
    df = get_data(df_src)
    if index_col in df.columns:
        df = df.set_index(index_col)
    if df[label_col].nunique() > 2:
        df[label] = (df[label_col].astype(int) > int(label[:-1])).astype(int)
    else:
        df[label] = df[label_col]


    if method == 'oot':
        df = df.sort_values(time_col, ascending=False)
        test = df.iloc[:int(df.shape[0] * test_size), ]
        train = df.iloc[int(df.shape[0] * test_size):, ]
    elif method == 'random':
        train, test = train_test_split(df, test_size=test_size, random_state=random_state)
    else:
        raise Exception(f'method {method} is not defined.')

    spliter_report(train, test, time_col, label, report_dst)
    del train[time_col], test[time_col]
    if label != label_col:
        del train[label_col], test[label_col]

    return train, test