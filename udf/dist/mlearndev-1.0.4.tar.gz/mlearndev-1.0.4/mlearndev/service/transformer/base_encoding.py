import pandas as pd
from ..base_utils import *
from pandas.api.types import is_numeric_dtype
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

class BaseEncoder(BaseEstimator, TransformerMixin):
    """
    用于剔除缺失值严重列，同值严重列，不同值严重cate列（字符串列如果取值太过于分散，则信息量过低）。

    适用于cont和cate，支持缺失值, 建议放置在encoder序列第一位次

    Parameters
    ----------
    missing_thr: 0.8, 缺失率高于该值的列会被剔除

    same_thr: 0.8, 同值率高于该值的列会被剔除

    caate_thr: 0.9， 取值分散率高于该值的字符串列会被剔除

    Attributes
    ----------
    missing_cols: list, 被剔除的缺失值列

    same_cols: list, 被剔除的同值列

    cate_cols: list, 被剔除的取值分散字符串列

    exclude_cols: list, 被剔除的列名
    """
    def __init__(self, missing_thr=0.8, same_thr=0.8, cate_thr=0.9):
        self.missing_thr = missing_thr
        self.same_thr = same_thr
        self.cate_thr = cate_thr

    def fit(self, X, y=None):
        df = pd.DataFrame(X.copy())
        tmp = df.dtypes.map(is_numeric_dtype)
        categorial_features = tmp[~tmp].index.values

        # 寻找缺失值严重列
        tmp = get_missing_value_ratio(df)
        self.missing_cols = list(tmp[tmp > self.missing_thr].index.values)

        # 寻找同值严重列
        tmp = get_same_value_ratio(df)
        self.same_cols = list(tmp[tmp > self.same_thr].index.values)

        # 寻找不同值严重cate列
        if len(categorial_features) > 0:
            tmp = df[categorial_features]
            tmp = tmp.nunique() / df.shape[0]
            self.cate_cols = list(tmp[tmp > self.cate_thr].index.values)
        else:
            self.cate_cols = list([])


        self.exclude_cols = list(set(self.missing_cols + self.same_cols + self.cate_cols))
        return self

    def transform(self, X):
        df = pd.DataFrame(X.copy())
        return df.drop(self.exclude_cols, axis=1)


class NothingEncoder(BaseEstimator, TransformerMixin):
    """
    原样返回，不做任何处理。本用于测试，现在transformer支持在encoders序列为空情况下原样返回，此类已无实际用途。

    适用于cont和cate，支持缺失值
    """
    def __init__(self):
        pass

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return pd.DataFrame(X)

class DropEncoder(BaseEstimator, TransformerMixin):
    """
    此类用于返回空df，换言之删除所有字段。

    适用于cont和cate， 支持缺失值
    """
    def __init__(self):
        pass

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return pd.DataFrame()

class ImputeEncoder(BaseEstimator, TransformerMixin):
    def __init__(self, fillna_value=-999):
        self.fillna_value = fillna_value

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        df = pd.DataFrame(X.copy())
        return df.replace(['nan', np.nan], self.fillna_value)
