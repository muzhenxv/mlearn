import pandas as pd
import numpy as np
from pandas.api.types import is_numeric_dtype
from .continous_encoding import *
from .category_encoding import *
from .custom_encoding import *
from .base_encoding import *
from ..data_service import get_data
import json
import pickle
import os
from itertools import chain
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.cluster import *


class ClusterGen(BaseEstimator, TransformerMixin):
    def __init__(self, method='KMeans', method_params=None, prefix='cluster'):
        self.method = method
        if method_params is None:
            self.method_params = {'random_state': 7}
        else:
            self.method_params = method_params
            self.method_params['random_state'] = 7
        self.prefix = prefix

    def fit(self, df, y=None):
        self.columns = df.columns

        self.enc = eval(self.method)(**self.method_params)
        self.fill_values = df.mean()
        self.enc.fit(df[self.fill_values])
        return self

    def transform(self, df):
        if list(df.columns) != self.columns:
            c = [c for c in self.columns if c not in df.columns]
            raise ValueError(f'Unexpected columns {c} are found!')
        tmp = self.enc.transform(df[self.fill_values])
        return pd.DataFrame(tmp, columns=[self.prefix + '_' + str(i) for i in range(tmp.shape[-1])])

