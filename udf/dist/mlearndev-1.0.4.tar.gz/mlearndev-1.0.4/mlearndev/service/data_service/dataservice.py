import pandas as pd

def get_data(src):
    if type(src) == pd.DataFrame:
        df = src
    elif src[-3:] == 'pkl':
        df = pd.read_pickle(src)
    elif src[-3:] == 'csv':
        df = pd.read_csv(src, index_col=0)
    else:
        raise Exception(f'{src} must be csv or pkl or pd.DataFrame!')
    return df