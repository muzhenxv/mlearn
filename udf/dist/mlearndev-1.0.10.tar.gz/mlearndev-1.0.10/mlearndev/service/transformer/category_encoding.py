from category_encoders import *
import numpy as np
from collections import Counter
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import OneHotEncoder


class CountEncoder(BaseEstimator, TransformerMixin):
    """
    count encoding: Replace categorical variables with count in the train set.
    replace unseen variables with 1.
    Can use log-transform to be avoid to sensitive to outliers.
    Only provide log-transform with base e, because I think it's enough.


    Attributes
    ----------
    map: a collections.Counter(which like dict) map variable's values to its frequency.

    Example
    -------
    enc = countencoder()
    enc.fit(['a','b','c', 'b', 'c', 'c'])
    enc.transform(['a','c','b'])
    Out:
    array([ 0.        ,  1.09861229,  0.69314718])

    """

    def __init__(self, unseen_value=0, log_transform=True, smoothing=1, inplace=True, prefix='_count'):
        """

        :param unseen_value: 在训练集中没有出现的值给予unseen_value的出现频次，然后参与smoothing
        :param log_transform: 是否取log
        :param smoothing: 光滑处理，在出现频次上+smoothing
        :param inplace: 是否删除原始字段
        """
        self.unseen_value = unseen_value
        self.log_transform = log_transform
        self.smoothing = smoothing
        self.inplace = inplace
        self.map = {}
        self.prefix = prefix

    def fit(self, X, y=None):
        """
        :param X: df
        :param y: None
        :return:
        """
        # TODO: 必须copy。不然使用df[c].replace这样的操作，会直接作用在X上。虽然不加copy，df和X， df[c]和X[c]的内存地址已经不一样。待查明！？
        # 如果不强转为str，那么如果有一列为float型，那么通过Counter或者pd.unique方法得到的结果result虽然也会有nan的存在，但是进行np.nan in result判断时会报False.
        df = pd.DataFrame(X.copy()).astype(str)

        self._set_unseen_key(df)

        for c in df.columns:
            dmap = Counter(df[c])
            for k in dmap.keys():
                dmap[k] += self.smoothing
            dmap[self.unseen_key] = self.unseen_value + self.smoothing
            self.map[c] = dmap

        self.columns = list(df.columns)
        return self

    def transform(self, X):
        """
        :param X: df
        :return:
        """
        # df[c].replace方法要求入参的字典key的类型必须和df[c]本身的数值类型一致，改用map方法无此问题
        df = pd.DataFrame(X.copy()).astype(str)
        if list(df.columns) != self.columns:
            c = [c for c in self.columns if c not in df.columns]
            raise ValueError(f'Unexpected columns {c} are found!')

        for c in self.columns:
            l = [i for i in df[c].unique() if i not in self.map[c].keys()]
            if len(l) > 0:
                df[c].replace(l, self.unseen_key, inplace=True)
            df[str(c) + self.prefix] = df[c].map(self.map[c])
            if self.inplace:
                del df[c]
        if self.log_transform:
            X = np.log(df)
        return X

    def _set_unseen_key(self, df):
        if type(df) != pd.DataFrame:
            df = pd.DataFrame(df)
        t = 'unknown'
        while t in df.values:
            t += '*'
        self.unseen_key = t


class CateLabelEncoder(BaseEstimator, TransformerMixin):
    """
    sklearn.preprocess.LabelEncoder can't process values which don't appear in fit label encoder.
    this method can process this problem. Replace all unknown values to a certain value, and encode this
    value to 0.

    Attributes
    ----------
    like sklearn.preprocess.LabelEncoder

    Example
    -------
    enc = labelencoder()
    enc.fit(['a','b','c'])
    enc.transform(['a','v','d'])
    Out: array([1, 0, 0])

    """

    def __init__(self, inplace=True, prefix='_label'):
        self.map = {}
        self.inplace = inplace
        self.prefix = prefix

    def fit(self, X, y=None):
        """
        :param X: array-like of shape (n_samples,)
        :param y: None
        :return:
        """
        df = pd.DataFrame(X.copy()).astype(str)

        self._set_unseen_key(df)

        num_start = 0
        for c in df.columns:
            unique_key = list(df[c].unique())
            unique_num = len(unique_key)
            self.map[c] = dict(zip(unique_key + [self.unseen_key], range(num_start, num_start + unique_num + 1)))
            num_start += unique_num + 1

        self.columns = list(df.columns)
        return self

    def transform(self, X):
        """
        :param X: array-like of shape (n_samples,)
        :return:
        """
        df = pd.DataFrame(X.copy()).astype(str)
        if list(df.columns) != self.columns:
            c = [c for c in self.columns if c not in df.columns]
            raise ValueError(f'Unexpected columns {c} are found!')

        for c in self.columns:
            l = [i for i in df[c].unique() if i not in self.map[c].keys()]
            if len(l) > 0:
                df[c].replace(l, self.unseen_key, inplace=True)
            df[str(c) + self.prefix] = df[c].map(self.map[c])
            if self.inplace:
                del df[c]
        return df

    def _set_unseen_key(self, df):
        if type(df) != pd.DataFrame:
            df = pd.DataFrame(df)
        t = 'unknown'
        while t in df.values:
            t += '*'
        self.unseen_key = t


class CateOneHotEncoder(BaseEstimator, TransformerMixin):
    def __init__(self, n_values="auto", categorical_features="all",
                 dtype=np.float64, sparse=True, handle_unknown='ignore', sparse_thr=200):
        self.n_values = n_values
        self.categorical_features = categorical_features
        self.dtype = dtype
        self.sparse = sparse
        self.handle_unknown = handle_unknown
        self.sparse_thr = sparse_thr
        self.onehot_params = self.get_params()
        del self.onehot_params['sparse_thr']

    def fit(self, X, y=None):
        self.le = CateLabelEncoder()
        self.le.fit(X)

        df = self.le.transform(X)

        self.onehot = OneHotEncoder(**self.onehot_params)
        self.onehot.fit(df)
        return self

    def transform(self, X):
        df = self.le.transform(X)
        df = self.onehot.transform(df)
        if df.shape[1] < 200:
            df = pd.DataFrame(df.todense())
            df.columns = [str(i)+'_onehot' for i in df.columns]
        return df
