import json
import simplejson
import numpy as np
from ..base_utils import *
import pandas as pd
from . import feature_evaluation

def table_to_dict(df):
    try:
        df.columns = df.columns.levels[0]
    except:
        pass
    df.index.name = 'feature'
    df = df.reset_index()
    return df.to_dict(orient='records')

class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)

class simplejsonEncoder(simplejson.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)

def data_stats_report(df):
    """
    数据描述性统计
    :param df:
    :return:
    """
    t1 = df.describe().T
    t2 = get_missing_value_ratio(df)
    t3 = get_same_value_ratio(df)

    t = pd.concat([t1, t2, t3], axis=1)

    return t

def feature_evaluation_report(df, y, **kwargs):
    """
    单特征iv，auc，ks计算
    :param df:
    :param y:
    :param kwargs:
    :return:
    """
    df = pd.concat([df, y], axis=1)
    df.fillna(-999, inplace=True)
    res = feature_evaluation.feature_evaluation(df, [y.names], **kwargs)
    return res

def get_feature_importances(enc):
    try:
        fi = enc.feature_importances_
    except:
        fi = enc.coef_[0]
    return fi
