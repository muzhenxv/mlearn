import pandas as pd
import numpy as np
import os
from .visualize import feature_plot, eva_plot
from . import feature_evaluation
import json
from .utils import MyEncoder, table_to_dict
from .feature_explore import cover_stats, target_stats


def spliter_report(df_train, df_test, time_col, label_col, report_dst):
    c_tr = cover_stats(df_train)
    c_te = cover_stats(df_test)
    c_tr.to_pickle(os.path.join(report_dst, 'c_tr.pkl'))
    c_te.to_pickle(os.path.join(report_dst, 'c_te.pkl'))
    dic = {'train': table_to_dict(c_tr), 'test': table_to_dict(c_te)}
    json.dump(dic, open(os.path.join(report_dst, 'cover_stats.json'), 'w'), cls=MyEncoder)


    d_tr = target_stats(df_train, label_col, time_col)
    d_te = target_stats(df_test, label_col, time_col)
    dic = {'train': d_tr, 'test': d_te}
    pd.DataFrame(dic).to_pickle(os.path.join(report_dst, 'target_stats.pkl'))
    json.dump(dic, open(os.path.join(report_dst, 'target_stats.json'), 'w'), cls=MyEncoder)


def transformer_report(df_train, df_test, label, report_dst):
    df_train.fillna(-999, inplace=True)
    train_plot_data = feature_plot(df_train, label, path=os.path.join(report_dst, 'train_feature_plot.png'))

    res = feature_evaluation.feature_evaluation(df_train, [label])
    res.to_pickle(report_dst + '/eva.pkl')
    res.to_csv(os.path.join(report_dst, 'train_feature_indices.csv'))
    train_text = table_to_dict(res)
    if df_test is not None:
        df_test.fillna(-999, inplace=True)
        test_plot_data = feature_plot(df_test, label, path=os.path.join(report_dst, 'test_feature_plot.png'))

        res = feature_evaluation.feature_evaluation(df_test, [label])
        res.to_csv(os.path.join(report_dst, 'test_feature_indices.csv'))
        test_text = table_to_dict(res)

    text = {'train': train_text, 'test': test_text}
    json.dump(text, open(os.path.join(report_dst, 'feature_indices.json'), 'w'), cls=MyEncoder)

    from itertools import chain
    from collections import defaultdict
    train_plot_data = {k: {'train': v} for k, v in train_plot_data.items()}
    test_plot_data = {k: {'test': v} for k, v in test_plot_data.items()}
    plot_data = defaultdict(dict)
    for k, v in chain(train_plot_data.items(), test_plot_data.items()):
        plot_data[k].update(v)
    json.dump(plot_data, open(os.path.join(report_dst, 'plot_data.json'), 'w'), cls=MyEncoder)


def filter_report(enc, score_func, report_dst):
    df = pd.DataFrame(enc.columns, columns=['feature_name'])
    df[score_func + '_pvalues'] = enc.enc.pvalues_
    df[score_func + '_scores'] = enc.enc.scores_
    df.to_csv(os.path.join(report_dst, 'filter_scores.csv'))
    data = df.sort_values(score_func + '_pvalues', ascending=True).to_dict(orient='records')
    json.dump(data, open(os.path.join(report_dst, 'feature_indices.json'), 'w'), cls=MyEncoder)


def optimizer_report(all_df, report_dst):
    all_df.to_csv(os.path.join(report_dst, 'all_params_result.csv'))
    json.dump(all_df.to_dict(orient='records'), open(os.path.join(report_dst, 'all_params_result.json'), 'w'))


def trainer_report(df_train, df_val, df_test, test_m, report_dst):
    eval_plot_path = os.path.join(report_dst, 'trainer_eva_report.png')
    dic_all = eva_plot({'train': [df_train.y_true, df_train.y_pred], 'val': [df_val.y_true, df_val.y_pred],
                        test_m: [df_test.y_true, df_test.y_pred]}, path=eval_plot_path)
    import re
    from collections import defaultdict
    dic = defaultdict(dict)
    token = re.compile('[\d.]+')
    for k in dic_all['roc_curve']:
        for v in dic_all['ks_curve'][k]:
            if v.startswith('KS'):
                s = float(re.findall(token, v)[0])
                #             dic[k].append({'ks': s})
                dic[k]['ks'] = s
    for v in dic_all['roc_curve']['train'].keys():
        k1, k2 = v.split('(')
        k1 = k1.strip()
        s = float(re.findall(token, k2)[0])
        #     dic[k1].append({'auc': s})
        dic[k1]['auc'] = s
    # df = pd.DataFrame.from_dict(dic)
    json.dump(dict(dic), open(os.path.join(report_dst, 'abstract_data.json'), 'w'), cls=MyEncoder)
    json.dump(dic_all, open(os.path.join(report_dst, 'eva_data.json'), 'w'), cls=MyEncoder)
