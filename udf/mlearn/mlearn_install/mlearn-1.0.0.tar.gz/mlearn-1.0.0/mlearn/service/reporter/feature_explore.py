import pandas as pd
import numpy as np
from collections import Counter
from collections import defaultdict
import os

def get_max_same_count(c):
    try:
        return c.value_counts().iloc[0]
    except:
        return len(c)

def desc_df(df_origin):
    df = df_origin.copy()

    df_desc = pd.DataFrame(df.isnull().sum(axis=0), columns=['null_num'])
    df_desc['notnull_num'] = df.shape[0] - df_desc['null_num']
    df_desc['notnull_ratio'] = df_desc['notnull_num'] / df.shape[0]

    nunique_value = df.apply(lambda c: c.nunique())
    df_desc['diff_values_num'] = nunique_value

    same_value = df.apply(get_max_same_count)
    df_desc['most_value_num'] = same_value
    df_desc['same_ratio'] = same_value / df.shape[0]

    return df_desc


def cover_stats(df, feature_map_dict=None):
    data_fg_r = (df.notnull().sum(axis=1) > 0).sum() / df.shape[0]

    t = desc_df(df)
    t = t[['notnull_ratio']]
    t.columns = ['覆盖率']

    t['饱和度'] = t['覆盖率'] / data_fg_r
    if feature_map_dict:
        t.index = pd.MultiIndex.from_tuples([(i, feature_map_dict[i]) for i in t.index])
        t1 = pd.DataFrame(columns=['覆盖率', '饱和度'])
        t1.ix[('dataset', '数据集'),] = [data_fg_r, np.nan]
        t = pd.concat([t1, t], axis=0)
    else:
        t1 = pd.DataFrame(columns=['覆盖率', '饱和度'])
        t1.loc['数据集'] = [data_fg_r, np.nan]
        t = pd.concat([t1, t], axis=0)

    return t


def target_stats(df_origin, target_col, time_col):
    dic = {}
    df = df_origin.copy()
    dic[target_col] = df[target_col].astype(int).mean()
    dic[f'{time_col}_start'] = df[time_col].min()
    dic[f'{time_col}_end'] = df[time_col].max()
    dic['sample_num'] = df.shape[0]

    return dic




