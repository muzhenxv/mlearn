import pandas as pd
from sklearn.feature_selection import *
from ..data_service import get_data
import numpy as np

class FeatureFilter:
    def __init__(self,  method, params):
        self.method = method
        self.params = params
        self.params['score_func'] = eval(self.params['score_func'])


    def fit(self, df_src, label):
        self.label = label
        df = get_data(df_src)
        df.fillna(-999, inplace=True)
        label = df.pop(label)
        if self.params['k'] > df.shape[1]:
            self.params['k'] = 'all'
        self.enc = eval(self.method)(**self.params)

        self.columns = list(df.columns)

        self.enc.fit(df, label)

    def fit_transform(self, df_src, label):
        self.label = label
        df = get_data(df_src)
        df.fillna(-999, inplace=True)
        label = df.pop(self.label)
        if self.params['k'] > df.shape[1]:
            self.params['k'] = 'all'
        self.enc = eval(self.method)(**self.params)

        self.columns = list(df.columns)

        df = pd.DataFrame(self.enc.fit_transform(df, label))
        df.columns = np.array(self.columns)[self.enc.get_support()]
        df.index = label.index
        df = pd.concat([df, label], axis=1)
        df.replace(-999, np.nan, inplace=True)
        return df

    def transform(self, df_src):
        df = get_data(df_src)
        df.fillna(-999, inplace=True)
        try:
            df_label = df.pop(self.label)
        except:
            df_label = pd.DataFrame()

        if list(df.columns) != self.columns:
            c = [c for c in self.columns if c not in df.columns]
            raise ValueError(f'Unexpected columns {c} are found!')

        df_final = pd.DataFrame(self.enc.transform(df))
        df_final.columns = np.array(self.columns)[self.enc.get_support()]

        df_final.index = df.index
        df_final = pd.concat([df_final, df_label], axis=1)
        df_final.replace(-999, np.nan, inplace=True)
        return df_final