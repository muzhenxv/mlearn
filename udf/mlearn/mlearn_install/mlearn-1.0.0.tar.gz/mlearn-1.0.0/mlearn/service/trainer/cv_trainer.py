import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import xgboost as xgb
from scipy.stats import ks_2samp
from sklearn import metrics as mr
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import train_test_split
from sklearn.linear_model import *
from sklearn.ensemble import *
from sklearn.naive_bayes import *
from sklearn.tree import *
from sklearn.svm import *
from xgboost.sklearn import XGBClassifier


def base_model_evaluation(df, target, method, params, n_folds=5, test_size=0, random_state=7, oversample=False,
                          verbose=True):
    if (test_size == 0) & (n_folds is None):
        raise Exception("Error: test_size and n_folds can't both invalid.")

    col_name = 'y_true'
    best_iteration = 0

    if oversample:
        pn_ratio = np.sum(target == 0) / np.sum(target == 1)
        if 'scale_pos_weight' in params:
            params['scale_pos_weight'] = pn_ratio

    train, test, train_y, test_y = train_test_split(df, target, test_size=test_size,
                                                    random_state=random_state)

    dic_cv = []

    if df.shape[1] == 1:
        if 'colsample_bytree' in params:
            params['colsample_bytree'] = 1

    if method == 'XGBClassifier':
        eval_metric = params.pop('eval_metric', 'auc')
        cv_verbose_eval = params.pop('verbose', False)
        early_stopping_rounds = params.pop('early_stopping_rounds', 30)

    if n_folds:
        df_val = pd.DataFrame()
        skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_state)
        for t_index, v_index in skf.split(train, train_y):
            tra, val = train.iloc[t_index, :], train.iloc[v_index, :]
            tra_y, val_y = train_y.iloc[t_index], train_y.iloc[v_index]

            if method == 'XGBClassifier':
                clf = eval(method)(**params)
                clf.fit(tra, tra_y, eval_set=[(tra, tra_y), (val, val_y)], eval_metric=eval_metric,
                        early_stopping_rounds=early_stopping_rounds, verbose=cv_verbose_eval)
                print('best_iteration: ', clf.best_iteration)
                best_iteration += clf.best_iteration
            else:
                clf = eval(method)(**params)
                clf.fit(tra, tra_y)

            if test_size > 0:
                temp = clf.predict_proba(test)[:, 1]
                dic_res = {'train_auc': roc_auc_score(tra_y, clf.predict_proba(tra)[:, 1]),
                           'val_auc': roc_auc_score(val_y, clf.predict_proba(val)[:, 1]),
                           'test_auc': roc_auc_score(test_y, temp)}
            else:
                dic_res = {'train_auc': roc_auc_score(tra_y, clf.predict_proba(tra)[:, 1]),
                           'val_auc': roc_auc_score(val_y, clf.predict_proba(val)[:, 1])}

            val_df = pd.DataFrame({'y_true': val_y, 'y_pred': clf.predict_proba(val)[:, 1]})
            df_val = pd.concat([df_val, val_df], axis=0)

            print(dic_res)
            dic_cv.append(dic_res)

        df_cv = cmpt_cv(dic_cv)
    else:
        df_cv = pd.DataFrame()
        df_val = pd.DataFrame()

    if test_size == 0:
        dvalid = (train, train_y)
        best_iteration = best_iteration // n_folds + 1
        early_stopping_rounds = None
    else:
        dvalid = (test, test_y)
        try:
            best_iteration = best_iteration // n_folds + 1
            early_stopping_rounds = None
        except:
            best_iteration = None

    if method == 'XGBClassifier':
        watchlist = [(train, train_y), dvalid]
        if best_iteration is not None:
            params['n_estimators'] = best_iteration
        best_iteration = params['n_estimators']
        clf = eval(method)(**params)
        clf.fit(train, train_y, eval_set=watchlist, eval_metric=eval_metric,
                early_stopping_rounds=early_stopping_rounds, verbose=verbose)
        print('best_iteration', best_iteration)
        print('early_stopping_rounds', early_stopping_rounds)
    else:
        clf = eval(method)(**params)
        clf.fit(train, train_y)

    if test_size > 0:
        pred_test = clf.predict_proba(test)[:, 1]
        df_test = pd.DataFrame({col_name: test_y, 'y_pred': pred_test})
    else:
        df_test = df_val
    pred_train = clf.predict_proba(train)[:, 1]
    df_train = pd.DataFrame({col_name: train_y, 'y_pred': pred_train})

    if df_val.shape[0] == 0:
        df_val = df_test
    return clf, df_cv, df_test, df_val, df_train


def cmpt_cv(dic_cv):
    df_cv = pd.DataFrame(dic_cv)
    df_cv = df_cv.describe().loc[['mean', 'std', 'min', 'max']]
    return df_cv
