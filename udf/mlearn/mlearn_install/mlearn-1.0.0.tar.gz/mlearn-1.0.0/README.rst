# data_utils

各种小功能。MD5加密，随机数生成等

# operatehdfs

hdfs读取与存储

# feature_explore

即将大规模重构

# feature_encoding

包含离散型数据的四种encoding方式，连续性数据的一种encoding方式

# feature_evaluation

特征评估，iv， ks， auc

# model_evaluation

模型评估，支持cv

# rule_learning

规则学习: 卡方评估，ripperk学习

# visualize

可视化模块，包含roc，ks，f1， 排序图以及决策树可视化

# facets

facets封装

# model_monitor

模型监控